package com.example.a3634assignment.Videos;

import android.content.Intent;
import android.net.Uri;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.VideoView;


import com.example.a3634assignment.Courses.CourseList;
import com.example.a3634assignment.Quizzes.QuizPage;
import com.example.a3634assignment.R;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class VideoPage extends YouTubeBaseActivity {

    private Button btnBackVideo;
    private Button btnTest;
    private FrameLayout frameLayout;
    private static final String TAG = "VideoPage";

    YouTubePlayerView mYoutubePlayerView;
    YouTubePlayer.OnInitializedListener mOnInitializedListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_page);

        mYoutubePlayerView = (YouTubePlayerView) findViewById(R.id.youtube_play);//frame for youtube video playing

        mOnInitializedListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer,
                                                boolean b){
                Log.d(TAG, "onClick: Done Initializing.");// if success
                youTubePlayer.loadVideo("mxZrsRMSOis"); // load video and video url
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult
                                               youTubeInitializationResult){
                Log.d(TAG, "onClick: Fail to initialize."); // if fail
            }

        };
// play video
        mYoutubePlayerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: Initializing Youtube Player.");
                mYoutubePlayerView.initialize(YoutubeConfig.getApiKey(),mOnInitializedListener);

            }
        });





        btnBackVideo = findViewById(R.id.video_back_btn);
        btnTest = findViewById(R.id.test_btn);

        btnBackVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VideoPage.this, CourseList.class);
                startActivity(intent);
            }
        });

    }



}
