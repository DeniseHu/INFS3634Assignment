package com.example.a3634assignment.Videos;

public class YoutubeConfig {
    public YoutubeConfig(){
    }
// store api keys
    private static final String API_KEY = "AIzaSyDApngtOzDT4gZxraqvHl1Jp__XUuRb8gc";

    public static String getApiKey(){
        return API_KEY;
    }

}
