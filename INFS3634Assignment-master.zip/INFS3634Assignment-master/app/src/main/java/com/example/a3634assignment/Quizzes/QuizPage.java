package com.example.a3634assignment.Quizzes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.a3634assignment.R;

public class QuizPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_page);
    }
}
